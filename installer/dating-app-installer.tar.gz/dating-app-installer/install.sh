#!/usr/bin/env bash
set -euo pipefail

# -------- CONFIG --------
APP_NAME="dating-app"
INSTALL_DIR="/opt/dating_app"
VENV_DIR="$INSTALL_DIR/.venv"
BIN_DIR="/usr/local/bin"
BIN_LINK="${BIN_DIR}/${APP_NAME}"
DESKTOP_DIR="${HOME}/.local/share/applications"
ICON_THEME_DIR="${HOME}/.local/share/icons/hicolor"
ICON_SRC_LOCAL="assets/dating-app.png"     # optional icon
ICON_DST_64="${ICON_THEME_DIR}/64x64/apps/dating-app.png"
# ------------------------

echo "==> Checking prerequisites"
command -v python3 >/dev/null || { echo "Python 3 required"; exit 1; }
command -v bash >/dev/null || { echo "bash required"; exit 1; }

echo "==> Creating install dir at ${INSTALL_DIR}"
sudo mkdir -p "${INSTALL_DIR}"
sudo cp -r src "${INSTALL_DIR}/"
if [[ -f requirements.txt ]]; then
  sudo cp requirements.txt "${INSTALL_DIR}/"
fi
if [[ -f "${ICON_SRC_LOCAL}" ]]; then
  sudo mkdir -p "${INSTALL_DIR}/assets"
  sudo cp "${ICON_SRC_LOCAL}" "${INSTALL_DIR}/assets/"
fi
sudo chown -R "${USER}:${USER}" "${INSTALL_DIR}"

echo "==> Creating virtualenv"
python3 -m venv "${VENV_DIR}"
"${VENV_DIR}/bin/python" -m pip install --upgrade pip
if [[ -f "${INSTALL_DIR}/requirements.txt" ]]; then
  "${VENV_DIR}/bin/pip" install -r "${INSTALL_DIR}/requirements.txt"
fi

echo "==> Creating launcher"
sudo tee "${INSTALL_DIR}/run.sh" >/dev/null <<'EOF'
#!/usr/bin/env bash
set -euo pipefail

# Resolve this script's real path (follows symlinks)
SCRIPT_PATH="$(readlink -f "${BASH_SOURCE[0]}")"
SCRIPT_DIR="$(dirname "$SCRIPT_PATH")"

INSTALL_DIR="$SCRIPT_DIR"
VENV="$INSTALL_DIR/.venv"

# Ensure installed sources are on sys.path
PYTHONPATH="${INSTALL_DIR}/src:${PYTHONPATH-}"
export PYTHONPATH

# Your code imports "from database import ..." etc., so run -m main
exec "$VENV/bin/python" -m main "$@"
EOF
sudo chmod +x "${INSTALL_DIR}/run.sh"

echo "==> Installing CLI symlink ${BIN_LINK}"
sudo mkdir -p "${BIN_DIR}"
sudo ln -sf "${INSTALL_DIR}/run.sh" "${BIN_LINK}"

echo "==> Installing desktop entry (user-level)"
mkdir -p "${DESKTOP_DIR}"
mkdir -p "$(dirname "${ICON_DST_64}")"

if [[ -f "${INSTALL_DIR}/assets/dating-app.png" ]]; then
  cp "${INSTALL_DIR}/assets/dating-app.png" "${ICON_DST_64}"
fi

DESKTOP_FILE="${DESKTOP_DIR}/${APP_NAME}.desktop"
cat > "${DESKTOP_FILE}" <<EOF
[Desktop Entry]
Type=Application
Version=1.0
Name=Dating App
Comment=Simple CLI dating app (matches, messages, notes)
TryExec=${APP_NAME}
Exec=${APP_NAME}
Terminal=true
Icon=dating-app
Categories=Utility;Network;
Keywords=dating;match;message;notes;
EOF

command -v update-desktop-database >/dev/null && update-desktop-database "${DESKTOP_DIR}" || true
command -v gtk-update-icon-cache >/dev/null && {
  mkdir -p "${ICON_THEME_DIR}"
  [[ -f "${ICON_THEME_DIR}/index.theme" ]] || printf "[Icon Theme]\nName=Hicolor\n" > "${ICON_THEME_DIR}/index.theme"
  gtk-update-icon-cache -f "${ICON_THEME_DIR}" || true
}

echo "==> Done!"
echo "Run from terminal: ${APP_NAME}"
echo "Or open from your applications menu: Dating App"
