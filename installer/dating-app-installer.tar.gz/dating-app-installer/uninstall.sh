#!/usr/bin/env bash
set -euo pipefail

APP_NAME="dating-app"
INSTALL_DIR="/opt/dating_app"
BIN_LINK="/usr/local/bin/${APP_NAME}"
DESKTOP_DIR="${HOME}/.local/share/applications"
DESKTOP_FILE="${DESKTOP_DIR}/${APP_NAME}.desktop"
ICON_THEME_DIR="${HOME}/.local/share/icons/hicolor"
ICON_DST_64="${ICON_THEME_DIR}/64x64/apps/dating-app.png"

read -r -p "Remove ${APP_NAME}? [y/N] " ans
[[ "${ans,,}" == "y" ]] || exit 0

echo "==> Removing CLI symlink"
sudo rm -f "${BIN_LINK}"

echo "==> Removing install dir"
sudo rm -rf "${INSTALL_DIR}"

echo "==> Removing desktop entry & icon"
rm -f "${DESKTOP_FILE}"
rm -f "${ICON_DST_64}"

command -v update-desktop-database >/dev/null && update-desktop-database "${DESKTOP_DIR}" || true
command -v gtk-update-icon-cache >/dev/null && gtk-update-icon-cache -f "${ICON_THEME_DIR}" || true

echo "Uninstalled."
